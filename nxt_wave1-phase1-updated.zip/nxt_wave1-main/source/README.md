# WhisperTriage AI — Complete Documentation

A single-page, offline-first web app that helps emergency responders
document and transmit patient triage information when cellular
networks are degraded or completely down. Runs entirely in the
browser, hosted as a static site on GitHub Pages.

---

## 1. The problem

During major disasters — earthquakes, power grid collapse, floods —
cellular networks commonly drop to 2G or fail outright. Responders
can't upload photos to cloud triage tools, can't call in patient
counts over a live connection, and existing crisis-response apps that
assume some baseline connectivity simply don't work.

What *does* usually survive in these conditions: short SMS bursts,
handheld radio, and device-to-device contact between responders and
relief teams as they move through an area. The gap this app targets
is turning a photo and a location into something that fits through
that narrow channel.

## 2. What the app does

1. **Capture.** The operator photographs a patient or scene (device
   camera, or file upload as a fallback).
2. **Analyze.** The photo is analyzed on-device for visual signals —
   redness, dark/charred tissue, irregular texture — see §4 for why
   this is a heuristic and not a downloaded model.
3. **Confirm.** The operator selects a START triage category
   (Immediate / Delayed / Minor / Expectant), which always overrides
   the automatic suggestion — see §5.
4. **Transmit.** Category, GPS coordinates, and timestamp are packed
   into a string under 100 bytes and rendered as a QR code, ready to
   be scanned device-to-device, read aloud over radio, or sent as an
   SMS.

Nothing is ever uploaded anywhere. There is no backend, no API key,
and no server this app talks to.

## 3. Architecture overview

```
[ Camera/Upload ] → [ Canvas resize to 224×224 ] → [ Pixel heuristic analysis ]
                                                              │
                                                              ▼
[ QR code output ] ← [ Bit-packed payload string ] ← [ Operator-confirmed triage ]
                                                              ▲
                                                              │
                                                    [ Browser Geolocation API ]
```

Every step happens inside the browser tab. The only "backend" is the
static file host (GitHub Pages) serving the initial HTML/CSS/JS.

## 4. Design decisions

### 4.1 Why pixel heuristics instead of a downloaded ML model

The first version of this app used `@xenova/transformers` to run a
quantized ONNX vision model in-browser via WebAssembly. In testing on
GitHub Pages, that approach failed to load — reliably. Two structural
reasons:

- It depends on the Hugging Face CDN being reachable from the
  visiting device/network. In a degraded-connectivity disaster
  scenario — the exact use case this app targets — that's an
  unreasonable assumption even *before* accounting for ordinary
  corporate firewalls, ad-blockers, or content-security policies.
- Modern WASM runtimes often want cross-origin-isolation headers
  (`Cross-Origin-Opener-Policy` / `Cross-Origin-Embedder-Policy`) for
  multi-threaded execution. GitHub Pages doesn't set these, and a
  static host has no mechanism to add them.

We evaluated bundling a small pretrained model directly in the repo
(avoiding the CDN dependency) — a real candidate exists
(`Hemg/Wound-Image-classification`, a fine-tuned ViT, 85.8M
parameters). We didn't use it: even quantized, that's realistically an
80-150MB one-time download, which directly contradicts the app's core
premise (§1) of working when networks are barely functional. A model
that can't finish downloading over 2G is a worse failure mode than no
model at all.

The replacement (`src/ai/visionHeuristics.js`) analyzes the photo via
`<canvas>` pixel math — hue/saturation/value color-space classification
of every pixel, tallying redness, charring, and texture irregularity.
This has zero network dependency, runs synchronously in milliseconds,
and cannot fail to "load" because nothing is loaded. It trades
model-grade accuracy for total reliability, which is the correct trade
for a tool whose entire reason to exist is working when nothing else
does.

### 4.2 Why HSV, not raw RGB

An early version of the heuristic checked "is red the dominant RGB
channel." That's wrong: ordinary human skin, across most skin tones,
is R>G>B in raw RGB (a mid-orange hue, roughly 15-40°) — so that check
flagged plain skin as an injury. Converting to HSV and requiring a hue
within ±12° of true red (0°/360°) at meaningful saturation separates
"skin-colored" from "actually red" correctly. This was caught and
fixed by testing against multiple synthetic skin tones (§6) before
shipping.

### 4.3 Why confidence-per-signal, not "highest score wins by default"

An early scoring formula computed a "no signal" (`UNIFORM`) score as
`1 - max(other signals)`. That's backwards for real photos: a
centered, cropped photo of an actual wound is still mostly normal
surrounding skin — the injury itself might be 10-15% of the frame, not
a majority. Under the old formula, that 10-15% redness lost to the
85-90% "everything else," so a genuinely injured hand was scored as
"no strong injury signal." (This is exactly what happened in real
testing — see §6.)

The fix: each signal (redness, charring, texture irregularity) is
scored independently against its own "ceiling" — the raw pixel ratio
at which that signal counts as fully present (e.g. 15% true-red pixels
= full confidence for the burn/bleeding signal). Any signal that
clears a minimum trigger floor is reported, regardless of what
fraction of the frame is normal skin. This models "is there a
meaningful injury signal present," not "which explanation covers the
most pixels."

### 4.4 Why manual override is always authoritative

`src/ai/triageEngine.js` treats the heuristic's output as one coarse
input signal. Whenever the operator makes a manual severity
selection, it overrides the heuristic completely — a trained
responder's field judgment should never be second-guessed by a color
heuristic. This is a deliberate scope boundary: the app is a
documentation/compression/transmission aid, not an autonomous
diagnostic device, and the UI, code comments, and this document say so
consistently rather than only in one disclaimer buried somewhere.

### 4.5 Why `base: './'` and why `sw.js` lives in `public/`

GitHub Pages serves a repository at
`https://<username>.github.io/<repo-name>/`, not at a domain root.
Vite's default absolute asset paths (`/assets/...`) break under a
subpath — `vite.config.js` sets `base: './'` so every reference is
relative to wherever `index.html` actually is. Separately, service
workers must be served from a stable, unhashed URL to control their
scope correctly, so `sw.js` is kept in `public/` (copied verbatim by
Vite) rather than `src/` (bundled and hash-renamed).

## 4.6 Vision model, upgraded (optional, still offline-only)

The app now has a real inference path alongside the heuristic, not
instead of it:

- `src/ai/visionModel.js` runs a genuine ONNX Runtime Web (WASM,
  single-threaded — see `public/models/README.md` for why) pipeline:
  real softmax confidence scores over 7 classes, plus **occlusion-
  sensitivity saliency** (Zeiler & Fergus 2014) as explainable AI — it
  re-runs inference with each region of the image blanked out and
  measures the confidence drop, so the highlighted region in the
  review screen is the part of the photo the model actually relied on,
  not a decorative overlay.
- This repo ships **without** a trained model file — see
  `public/models/README.md` for exact input/output spec and how to
  train and drop one in.
- `src/ai/analysisPipeline.js` is the single entry point the UI calls:
  it checks for a model file, uses it if present and it doesn't throw,
  and otherwise falls back to the same Canvas heuristic described in
  §4.1-4.3, completely unchanged. The UI always shows which path
  produced a given result (`analysis.source`) — it never presents a
  heuristic guess as a model's output or vice versa.
- The ONNX JS bindings and WASM runtime (~7MB) are dynamically
  imported only once a model file is confirmed present, so the default
  no-model bundle stays small (see `npm run build` output).

## 4.7 START protocol as a real guided assessment

The single severity slider from the original app is still available
("Quick manual" tab), but the default tab now walks the actual START
decision tree (`src/ai/triageEngine.js::runSTART`) one question at a
time — ambulatory → respirations → perfusion → mental status — the
real field algorithm, not a proxy for it. Each result includes a
plain-language trace of which branch was taken and why, shown to the
operator. A rules-based `runSTART` result always takes priority over
the vision signal when present, for the same reason manual override
does (§4.4): direct patient assessment outranks a photo.

## 4.8 Body map, offline storage, and analytics

- `src/components/BodyMap.jsx` — tap-to-mark SVG figure (front/back)
  for attaching structured injury-location tags to a report without
  typing.
- `src/utils/db.js` — every generated report is persisted to
  IndexedDB (via `idb`) on this device, independent of whether it's
  ever relayed onward. This is what makes the app usable across
  multiple patients over hours with zero connectivity, and gives the
  analytics view real local data.
- `src/components/AnalyticsDashboard.jsx` — reads directly from
  IndexedDB (no network): totals by START category, an activity
  timeline for the last 24h, and counts by finding. Useful for an
  on-scene coordinator reviewing what's been triaged at this device or
  relay point so far. Includes a manual "clear local data" action.
- A pending-sync counter in the header reflects reports saved locally
  that haven't been marked relayed — "sync" here means marked ready
  for handoff (QR/SMS/radio) by the operator, since this app makes no
  network calls of its own.

## 4.9 Resilience

- `src/components/ErrorBoundary.jsx` wraps the whole app so a single
  bad frame or unexpected model/IndexedDB failure can't white-screen
  the tool mid-incident; already-saved reports are unaffected.
- Every new async path (model load, model inference, IndexedDB writes)
  is wrapped in try/catch with a fallback that keeps the operator
  moving rather than blocking on an error.

## 5. START triage protocol

The app aligns its four categories to Simple Triage and Rapid
Treatment, the standard mass-casualty field protocol:

| Category | Color | Meaning |
|---|---|---|
| Immediate | Red | Life-threatening, needs care within minutes |
| Delayed | Yellow | Serious but stable enough to wait |
| Minor | Green | Walking wounded |
| Expectant | Black | Injuries incompatible with survival given available resources |

## 6. Testing methodology

The heuristic was validated three ways before shipping, all
reproducible from the source tree:

1. **Synthetic skin tones.** Four RGB values spanning a range of skin
   tones were run through `analyzeImage()` directly (via a mock
   canvas object in Node, exercising the real shipped module, not a
   reimplementation). All four correctly scored "no strong injury
   signal" — confirming no false positive on plain skin.
2. **Synthetic injury patterns.** A pixel mix simulating charred
   tissue, and a separate mix simulating a red/bleeding wound, were
   each run through the same real module and correctly triggered
   their respective signals at full confidence.
3. **Real photo.** A real photo of an injured hand (submitted during
   development) was cropped, resized to the model's 224×224 analysis
   resolution, and run through the actual shipped `visionHeuristics.js`
   via a mock-canvas harness in Node. This is what caught the §4.3
   scoring bug — the first formula scored this real, visibly injured
   hand as "no strong injury signal" at 80% confidence. The corrected
   formula scores it "true-red hue detected" at 61% confidence.

If you change the thresholds in `visionHeuristics.js`, re-run this
kind of check before shipping — synthetic test patterns alone didn't
catch the real-photo bug; a real photo did.

## 7. Known limitations

- The heuristic is a color/texture signal, not a clinical
  classifier. It cannot distinguish burn severity degrees, cannot
  identify fractures, and has no understanding of anatomy. It is
  explicitly designed to be overridden by the operator (§4.4).
- Redness detection depends on lighting conditions; strong colored
  ambient lighting (e.g. red emergency lighting) could shift results.
- The QR payload has no encryption — it's a plain compressed string,
  appropriate for its intended use (immediate device-to-device or
  radio relay by responders on-scene) but not for long-term storage of
  sensitive data.
- Geolocation requires the operator to grant browser permission; if
  denied, the report is still generated but without coordinates.

## 8. Local development

```bash
npm install
npm run dev
```

## 9. Build

```bash
npm run build
```

Outputs a fully static site to `dist/`.

## 10. Deploying to GitHub Pages

**`index.html` must sit at the root of whatever GitHub Pages serves.**
Pages serves files exactly as given — it does not run a build step for
you.

**Option A — push `dist/` contents directly**
Run `npm run build`, then push the *contents* of `dist/` (not the
`dist` folder itself) to the branch/folder Settings → Pages is
configured to serve, so `index.html` lands directly at that root.

**Option B — GitHub Actions (automatic on every push)**
This repo includes `.github/workflows/deploy.yml`. Push the full
source to `main`, set Settings → Pages → Source to "GitHub Actions",
and it builds and deploys `dist/` automatically on every push.

**If you deployed before and still see old behavior:** browsers cache
the service worker aggressively. Open DevTools → Application →
Service Workers → Unregister, then Application → Storage → Clear site
data, then hard-refresh. The service worker's cache name is bumped
(`whispertriage-shell-v3`) specifically to force this invalidation on
this release.

## 11. Project structure

```
whispertriage/
├── .github/workflows/deploy.yml   # Optional CI/CD to GitHub Pages
├── public/
│   ├── manifest.json              # PWA manifest
│   ├── sw.js                      # Offline service worker
│   └── icons/                     # PWA home-screen icons
├── src/
│   ├── ai/
│   │   ├── visionHeuristics.js    # Canvas pixel-analysis (redness/char/texture)
│   │   └── triageEngine.js        # START-protocol classification logic
│   ├── components/
│   │   ├── CameraModule.jsx       # Camera capture / upload fallback
│   │   ├── SeveritySlider.jsx     # Manual operator override
│   │   └── QROutput.jsx           # QR code + raw payload display
│   ├── utils/
│   │   ├── encoder.js             # Bit-packing payload compression
│   │   ├── geoHandler.js          # Geolocation API wrapper
│   │   └── imageCompressor.js     # Canvas-based image resizing
│   ├── App.jsx                    # Application flow / state machine
│   ├── App.css / index.css        # Styling
│   └── main.jsx                   # React mount + SW registration
├── vite.config.js                 # base: './' for GitHub Pages
└── package.json
```

## 12. Possible future work

- Tune heuristic ceilings against a larger, more diverse set of real
  photos (skin tones, lighting conditions, injury types) than the
  single validation photo used here.
- Add a compressed thumbnail into the QR payload itself for very
  short-range device-to-device scanning, trading payload size for a
  visual reference at the receiving end.
- Optional, explicitly opt-in bundled ML model for responders who can
  tolerate a larger initial download and want higher-fidelity
  suggestions — additive to the heuristic, never a replacement for it.
