# Adding a real vision model

This folder is intentionally empty of a model file in this repository.
`src/ai/analysisPipeline.js` probes for `wound-classifier.onnx` here at
startup; if it's missing, the app **cleanly falls back** to the
deterministic Canvas heuristic (`src/ai/visionHeuristics.js`) and says
so in the UI (`analysis.fallbackReason`). Nothing is faked.

## Requirements for a compatible model

- **Format:** ONNX (opset 12+), single input, single output.
- **Input:** `[1, 3, 224, 224]` float32, NCHW, ImageNet-normalized
  (mean `[0.485, 0.456, 0.406]`, std `[0.229, 0.224, 0.225]`) — this
  exact preprocessing is already implemented in
  `src/utils/imageCompressor.js::canvasToTensorData`.
- **Output:** raw logits over 7 classes, in this exact order (see
  `src/ai/visionModel.js::CLASS_LABELS`):
  1. No significant finding
  2. First-degree burn
  3. Second-degree burn
  4. Third-degree / charred tissue
  5. Laceration / open wound
  6. Active hemorrhage signal
  7. Suspected fracture deformity

  (The pipeline applies softmax itself — ship raw logits, not
  probabilities.)

## Getting a model

1. **Fine-tune something small.** A MobileNetV3-Small or
   EfficientNet-Lite0 backbone fine-tuned on a labeled wound/injury
   image set, with a 7-class head matching the order above, keeps the
   quantized export in the 3-10MB range — small enough to be a
   reasonable one-time download even on a poor connection, unlike the
   80-150MB ViT this project's README documents rejecting.
2. **Export to ONNX** (from PyTorch: `torch.onnx.export(...)`, or from
   TensorFlow/Keras via `tf2onnx`).
3. **Quantize** to int8 or float16 with `onnxruntime.quantization` to
   shrink the download further.
4. **Drop the file here** as `wound-classifier.onnx`. No code changes
   needed — `isModelAvailable()` will detect it automatically on next
   load.
5. **Re-run the existing test methodology** described in the main
   README §6 (synthetic skin tones, synthetic injury patterns, real
   photos) against the model path, not just the heuristic path, before
   trusting it in the field.

## Why single-threaded WASM

`src/ai/visionModel.js` forces `ort.env.wasm.numThreads = 1`.
Multi-threaded ONNX Runtime Web needs `SharedArrayBuffer`, which
requires `Cross-Origin-Opener-Policy` / `Cross-Origin-Embedder-Policy`
response headers — GitHub Pages (this app's deploy target) cannot set
those. Single-threaded is slower but works on a plain static host with
zero server configuration, consistent with this project's existing
reliability-over-performance stance.
