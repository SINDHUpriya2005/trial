import { useState } from 'react';
import { runSTART, CATEGORY_META } from '../ai/triageEngine.js';

/**
 * StartAssessment
 * Walks the operator through the actual START algorithm one question
 * at a time (rather than a single ambiguous slider), and shows the
 * resulting category plus a plain-language trace of *why* — the
 * clinical equivalent of the vision model's occlusion-saliency
 * explainability, but for the rules-based side of the app.
 */
export default function StartAssessment({ onComplete }) {
  const [step, setStep] = useState('canWalk');
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);

  function answer(key, value) {
    const next = { ...answers, [key]: value };
    setAnswers(next);

    const advance = () => {
      if (key === 'canWalk') {
        if (value) return finish(next);
        return setStep('isBreathing');
      }
      if (key === 'isBreathing') {
        return value ? setStep('respiratoryRate') : setStep('repositioned');
      }
      if (key === 'repositioned') {
        return setStep('breathingAfterReposition');
      }
      if (key === 'breathingAfterReposition') {
        return finish(next);
      }
      if (key === 'respiratoryRate') {
        return setStep('radialPulsePresent');
      }
      if (key === 'radialPulsePresent') {
        return value ? setStep('canFollowCommands') : finish(next);
      }
      if (key === 'canFollowCommands') {
        return finish(next);
      }
      return finish(next);
    };

    advance();
  }

  function finish(finalAnswers) {
    const r = runSTART(finalAnswers);
    setResult(r);
    setStep('done');
    onComplete(r, finalAnswers);
  }

  if (step === 'done' && result) {
    const meta = CATEGORY_META[result.category];
    return (
      <div className="start-assessment start-result">
        <div className={`triage-banner cat-${result.category.toLowerCase()}`}>
          <span className="triage-color-dot" />
          <div>
            <p className="triage-category">
              START result: {meta.label} — {meta.color}
            </p>
          </div>
        </div>
        <ol className="start-reasoning">
          {result.reasoning.map((line, i) => (
            <li key={i}>{line}</li>
          ))}
        </ol>
        <button className="btn btn-ghost" type="button" onClick={() => { setStep('canWalk'); setAnswers({}); setResult(null); }}>
          Restart assessment
        </button>
      </div>
    );
  }

  return (
    <div className="start-assessment">
      <p className="section-label">Guided START assessment</p>
      {step === 'canWalk' && (
        <Question
          prompt="Can the patient walk to a collection point unassisted?"
          onYes={() => answer('canWalk', true)}
          onNo={() => answer('canWalk', false)}
        />
      )}
      {step === 'isBreathing' && (
        <Question
          prompt="Is the patient breathing?"
          onYes={() => answer('isBreathing', true)}
          onNo={() => answer('isBreathing', false)}
        />
      )}
      {step === 'repositioned' && (
        <Question
          prompt="Reposition the airway (head-tilt/chin-lift). Did you attempt this?"
          onYes={() => answer('repositioned', true)}
          onNo={() => answer('repositioned', false)}
        />
      )}
      {step === 'breathingAfterReposition' && (
        <Question
          prompt="Is the patient breathing now, after repositioning?"
          onYes={() => answer('breathingAfterReposition', true)}
          onNo={() => answer('breathingAfterReposition', false)}
        />
      )}
      {step === 'respiratoryRate' && (
        <div className="start-question">
          <p>Approximate respiratory rate (breaths/min)?</p>
          <div className="severity-options">
            {[12, 20, 28, 35].map((rate) => (
              <button
                key={rate}
                type="button"
                className="severity-chip"
                onClick={() => answer('respiratoryRate', rate)}
              >
                {rate === 35 ? '30+' : `~${rate}`}
              </button>
            ))}
          </div>
        </div>
      )}
      {step === 'radialPulsePresent' && (
        <Question
          prompt="Is a radial pulse present, or capillary refill under 2 seconds?"
          onYes={() => answer('radialPulsePresent', true)}
          onNo={() => answer('radialPulsePresent', false)}
        />
      )}
      {step === 'canFollowCommands' && (
        <Question
          prompt="Can the patient follow simple commands (e.g. squeeze your hand)?"
          onYes={() => answer('canFollowCommands', true)}
          onNo={() => answer('canFollowCommands', false)}
        />
      )}
    </div>
  );
}

function Question({ prompt, onYes, onNo }) {
  return (
    <div className="start-question">
      <p>{prompt}</p>
      <div className="start-yn">
        <button type="button" className="btn btn-ghost" onClick={onNo}>
          No
        </button>
        <button type="button" className="btn btn-primary" onClick={onYes}>
          Yes
        </button>
      </div>
    </div>
  );
}
