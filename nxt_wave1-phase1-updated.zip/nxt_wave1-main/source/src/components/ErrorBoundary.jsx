import { Component } from 'react';
import { AlertTriangle } from 'lucide-react';

/**
 * ErrorBoundary
 * Catches render-time exceptions anywhere below it so a single bad
 * frame, corrupted IndexedDB record, or unexpected model output can't
 * white-screen the whole app in the field. Offers a reset that clears
 * local component state without losing already-synced reports.
 */
export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    console.error('WhisperTriage crashed:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="app-shell">
          <div className="error-boundary" role="alert">
            <AlertTriangle size={28} />
            <h2>Something went wrong</h2>
            <p>
              The app hit an unexpected error. Your previously saved reports are still stored
              on this device and were not affected.
            </p>
            <p className="error-detail">{String(this.state.error?.message || this.state.error)}</p>
            <button
              className="btn btn-primary"
              type="button"
              onClick={() => this.setState({ hasError: false, error: null })}
            >
              Try again
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
