import { useEffect, useState } from 'react';
import { BarChart3, RefreshCw, Trash2 } from 'lucide-react';
import { getAnalyticsSummary, clearAllReports } from '../utils/db.js';
import { CATEGORY_META } from '../ai/triageEngine.js';
import { FINDINGS_CODE_TABLE } from '../utils/encoder.js';

/**
 * AnalyticsDashboard
 * Reads directly from IndexedDB — no network, no cloud aggregation.
 * Useful for an incident commander reviewing what's been triaged on
 * this specific device/relay point so far.
 */
export default function AnalyticsDashboard({ onClose, refreshKey }) {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const s = await getAnalyticsSummary();
    setSummary(s);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, [refreshKey]);

  async function handleClear() {
    if (!window.confirm('Clear all locally stored reports? This cannot be undone.')) return;
    await clearAllReports();
    load();
  }

  const maxHour = summary ? Math.max(...summary.hourBuckets, 1) : 1;

  return (
    <div className="analytics-dashboard">
      <div className="analytics-header">
        <div className="brand">
          <BarChart3 size={18} />
          <span>On-device analytics</span>
        </div>
        <div className="analytics-actions">
          <button className="btn btn-icon" onClick={load} title="Refresh" type="button">
            <RefreshCw size={14} />
          </button>
          <button className="btn btn-ghost" onClick={onClose} type="button">
            Close
          </button>
        </div>
      </div>

      {loading && <p className="stage-note">Reading local records…</p>}

      {!loading && summary && summary.total === 0 && (
        <p className="stage-note">No reports stored on this device yet.</p>
      )}

      {!loading && summary && summary.total > 0 && (
        <>
          <div className="analytics-stat-row">
            <Stat label="Total reports" value={summary.total} />
            <Stat label="Pending sync" value={summary.unsynced} />
            <Stat label="Avg. confidence" value={`${Math.round(summary.avgConfidence * 100)}%`} />
          </div>

          <p className="section-label">By START category</p>
          <div className="analytics-category-bars">
            {Object.entries(summary.byCategory).map(([cat, count]) => (
              <div className="category-bar-row" key={cat}>
                <span className={`category-bar-label cat-${cat.toLowerCase()}`}>
                  {CATEGORY_META[cat].label}
                </span>
                <div className="category-bar-track">
                  <div
                    className={`category-bar-fill cat-${cat.toLowerCase()}`}
                    style={{ width: `${summary.total ? (count / summary.total) * 100 : 0}%` }}
                  />
                </div>
                <span className="category-bar-count">{count}</span>
              </div>
            ))}
          </div>

          <p className="section-label">Activity, last 24h</p>
          <div className="analytics-timeline" role="img" aria-label="Reports per hour, last 24 hours">
            {summary.hourBuckets.map((count, i) => (
              <div
                key={i}
                className="timeline-bar"
                style={{ height: `${Math.max((count / maxHour) * 100, count > 0 ? 8 : 2)}%` }}
                title={`${count} report${count === 1 ? '' : 's'}, ${23 - i}h ago`}
              />
            ))}
          </div>

          <p className="section-label">By finding</p>
          <div className="analytics-findings">
            {Object.entries(summary.byFinding)
              .sort((a, b) => b[1] - a[1])
              .map(([code, count]) => (
                <div className="finding-row" key={code}>
                  <span>{FINDINGS_CODE_TABLE[code] || code}</span>
                  <span>{count}</span>
                </div>
              ))}
          </div>

          <button className="btn btn-ghost btn-danger" onClick={handleClear} type="button">
            <Trash2 size={14} /> Clear local data
          </button>
        </>
      )}
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="analytics-stat">
      <span className="analytics-stat-value">{value}</span>
      <span className="analytics-stat-label">{label}</span>
    </div>
  );
}
