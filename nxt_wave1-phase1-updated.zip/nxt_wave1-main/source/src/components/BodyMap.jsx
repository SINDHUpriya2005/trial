import { useState } from 'react';
import { RotateCw } from 'lucide-react';

/**
 * BodyMap
 * Tap-to-mark interactive human figure (front/back toggle) so the
 * operator can attach injury locations to the report without typing —
 * critical when hands are gloved/wet or the operator is one-handed
 * while stabilizing a patient.
 *
 * Regions are simple named SVG hit-areas rather than free-form
 * click coordinates, so the resulting data is structured (a list of
 * region ids) rather than raw pixels — cheap to transmit and to
 * aggregate on the analytics dashboard.
 */

const FRONT_REGIONS = [
  { id: 'head', label: 'Head', d: 'M50,6 a14,14 0 1,0 0.01,0 Z' },
  { id: 'neck', label: 'Neck', x: 44, y: 20, w: 12, h: 6 },
  { id: 'chest', label: 'Chest', x: 34, y: 26, w: 32, h: 20 },
  { id: 'abdomen', label: 'Abdomen', x: 36, y: 46, w: 28, h: 16 },
  { id: 'l-arm', label: 'Left arm', x: 14, y: 26, w: 16, h: 40 },
  { id: 'r-arm', label: 'Right arm', x: 70, y: 26, w: 16, h: 40 },
  { id: 'pelvis', label: 'Pelvis', x: 36, y: 62, w: 28, h: 10 },
  { id: 'l-leg', label: 'Left leg', x: 34, y: 72, w: 14, h: 42 },
  { id: 'r-leg', label: 'Right leg', x: 52, y: 72, w: 14, h: 42 }
];

const BACK_REGIONS = FRONT_REGIONS.map((r) =>
  r.id === 'chest'
    ? { ...r, id: 'upper-back', label: 'Upper back' }
    : r.id === 'abdomen'
    ? { ...r, id: 'lower-back', label: 'Lower back' }
    : r
);

export default function BodyMap({ selected = [], onChange }) {
  const [view, setView] = useState('front');
  const regions = view === 'front' ? FRONT_REGIONS : BACK_REGIONS;

  function toggleRegion(id) {
    const next = selected.includes(id) ? selected.filter((r) => r !== id) : [...selected, id];
    onChange(next);
  }

  return (
    <div className="body-map">
      <div className="body-map-header">
        <p className="section-label">Injury location (optional)</p>
        <button
          type="button"
          className="btn btn-icon"
          onClick={() => setView((v) => (v === 'front' ? 'back' : 'front'))}
          aria-label={`Switch to ${view === 'front' ? 'back' : 'front'} view`}
          title="Flip view"
        >
          <RotateCw size={14} />
        </button>
      </div>

      <svg
        viewBox="0 0 100 116"
        className="body-map-svg"
        role="group"
        aria-label={`Human body diagram, ${view} view — tap a region to mark it`}
      >
        {regions.map((r) =>
          r.d ? (
            <path
              key={r.id}
              d={r.d}
              className={`body-region ${selected.includes(r.id) ? 'active' : ''}`}
              onClick={() => toggleRegion(r.id)}
              role="button"
              tabIndex={0}
              aria-pressed={selected.includes(r.id)}
              aria-label={r.label}
              onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && toggleRegion(r.id)}
            >
              <title>{r.label}</title>
            </path>
          ) : (
            <rect
              key={r.id}
              x={r.x}
              y={r.y}
              width={r.w}
              height={r.h}
              rx={3}
              className={`body-region ${selected.includes(r.id) ? 'active' : ''}`}
              onClick={() => toggleRegion(r.id)}
              role="button"
              tabIndex={0}
              aria-pressed={selected.includes(r.id)}
              aria-label={r.label}
              onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && toggleRegion(r.id)}
            >
              <title>{r.label}</title>
            </rect>
          )
        )}
      </svg>

      {selected.length > 0 && (
        <div className="body-map-tags">
          {selected.map((id) => {
            const region = [...FRONT_REGIONS, ...BACK_REGIONS].find((r) => r.id === id);
            return (
              <span key={id} className="body-tag">
                {region ? region.label : id}
              </span>
            );
          })}
        </div>
      )}
    </div>
  );
}
