/**
 * SaliencyOverlay
 * Renders the occlusion-sensitivity grid computed by visionModel.js
 * as a semi-transparent heatmap over the analyzed frame — the
 * explainable-AI layer: it shows *where* in the image the model's
 * top prediction actually came from, not just a bare confidence
 * number.
 */
export default function SaliencyOverlay({ saliency, gridSize }) {
  if (!saliency || !gridSize) return null;

  const cellPct = 100 / gridSize;

  return (
    <div className="saliency-overlay" aria-hidden="true">
      {saliency.flatMap((row, r) =>
        row.map((value, c) => (
          <div
            key={`${r}-${c}`}
            className="saliency-cell"
            style={{
              left: `${c * cellPct}%`,
              top: `${r * cellPct}%`,
              width: `${cellPct}%`,
              height: `${cellPct}%`,
              opacity: value * 0.55
            }}
          />
        ))
      )}
      <span className="saliency-caption">Model attention (occlusion sensitivity)</span>
    </div>
  );
}
