import { useState, useCallback, useMemo } from 'react';
import {
  ShieldAlert,
  MapPin,
  Wifi,
  WifiOff,
  Loader2,
  ChevronRight,
  BarChart3,
  CloudOff,
  Info
} from 'lucide-react';
import CameraModule from './components/CameraModule.jsx';
import SeveritySlider from './components/SeveritySlider.jsx';
import QROutput from './components/QROutput.jsx';
import BodyMap from './components/BodyMap.jsx';
import StartAssessment from './components/StartAssessment.jsx';
import AnalyticsDashboard from './components/AnalyticsDashboard.jsx';
import SaliencyOverlay from './components/SaliencyOverlay.jsx';
import { runVisionAnalysis } from './ai/analysisPipeline.js';
import { evaluateTriage, CATEGORY_META } from './ai/triageEngine.js';
import { resizeImage } from './utils/imageCompressor.js';
import { getCurrentPosition, formatCoords } from './utils/geoHandler.js';
import { packPayload } from './utils/encoder.js';
import { saveReport, getUnsyncedCount } from './utils/db.js';
import './App.css';

const STAGES = {
  CAPTURE: 'capture',
  ANALYZING: 'analyzing',
  REVIEW: 'review',
  RESULT: 'result'
};

export default function App() {
  const [stage, setStage] = useState(STAGES.CAPTURE);
  const [rawImage, setRawImage] = useState(null);
  const [preview, setPreview] = useState(null);
  const [analysis, setAnalysis] = useState(null); // { source, predictions, saliency, gridSize, fallbackReason }
  const [manualSeverity, setManualSeverity] = useState(null);
  const [startResult, setStartResult] = useState(null);
  const [bodyRegions, setBodyRegions] = useState([]);
  const [coords, setCoords] = useState(null);
  const [geoError, setGeoError] = useState(null);
  const [analysisError, setAnalysisError] = useState(null);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [savedReportId, setSavedReportId] = useState(null);
  const [unsyncedCount, setUnsyncedCount] = useState(0);
  const [assessmentMode, setAssessmentMode] = useState('start'); // 'start' | 'manual'
  const isOnline = useOnlineStatus();

  const refreshUnsynced = useCallback(() => {
    getUnsyncedCount().then(setUnsyncedCount).catch(() => {});
  }, []);

  const requestLocation = useCallback(() => {
    setGeoError(null);
    getCurrentPosition()
      .then((pos) => setCoords(formatCoords(pos.lat, pos.lon)))
      .catch((err) => setGeoError(err.message));
  }, []);

  const handleCapture = useCallback(
    async (dataUrl) => {
      setRawImage(dataUrl);
      setStage(STAGES.ANALYZING);
      setAnalysisError(null);

      // Kick off geolocation in parallel — it should not block analysis.
      requestLocation();

      try {
        const { canvas, dataUrl: preview } = await resizeImage(dataUrl, 224);
        setPreview(preview);

        // Real ONNX model when available, deterministic Canvas
        // heuristic fallback otherwise — see ai/analysisPipeline.js.
        const result = await runVisionAnalysis(canvas);
        setAnalysis(result);
        setStage(STAGES.REVIEW);
      } catch (err) {
        console.error(err);
        setAnalysisError(
          'Image analysis failed to run on this photo. You can still submit a manual or START assessment below.'
        );
        setAnalysis(null);
        setStage(STAGES.REVIEW);
      }
    },
    [requestLocation]
  );

  const predictions = analysis?.predictions || [];

  const triage = useMemo(() => {
    if (startResult) {
      // START result (rules-based clinical protocol) takes priority
      // over any vision signal when the operator has run it — it's
      // derived from direct patient assessment, not imagery.
      const findingsCode = predictions[0]
        ? evaluateTriageFinding(predictions[0].label) ?? 'UNK'
        : 'UNK';
      const meta = CATEGORY_META[startResult.category];
      return {
        category: startResult.category,
        color: meta.color,
        label: meta.label,
        priority: meta.priority,
        findingsCode,
        confidence: 1.0,
        source: 'start-protocol',
        rawTopLabel: predictions[0]?.label || null
      };
    }
    return predictions.length || manualSeverity ? evaluateTriage(predictions, manualSeverity) : null;
  }, [predictions, manualSeverity, startResult]);

  const payload = triage ? packPayload(triage, coords) : null;

  async function handleGenerateCode() {
    if (!triage || !payload) return;
    try {
      const id = await saveReport({
        timestamp: Date.now(),
        category: triage.category,
        findingsCode: triage.findingsCode,
        confidence: triage.confidence,
        source: triage.source,
        payload,
        coords,
        bodyRegions,
        thumbnail: preview
      });
      setSavedReportId(id);
      refreshUnsynced();
    } catch (err) {
      console.error('Failed to save report locally:', err);
      // Non-fatal — the QR/payload is still shown even if local
      // persistence fails (e.g. private browsing mode).
    }
    setStage(STAGES.RESULT);
  }

  function reset() {
    setStage(STAGES.CAPTURE);
    setRawImage(null);
    setPreview(null);
    setAnalysis(null);
    setManualSeverity(null);
    setStartResult(null);
    setBodyRegions([]);
    setCoords(null);
    setGeoError(null);
    setAnalysisError(null);
    setSavedReportId(null);
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="brand">
          <ShieldAlert size={22} />
          <span>WhisperTriage AI</span>
        </div>
        <div className="header-actions">
          {unsyncedCount > 0 && (
            <span className="sync-badge" title={`${unsyncedCount} report(s) pending relay`}>
              <CloudOff size={12} /> {unsyncedCount}
            </span>
          )}
          <button
            className="btn btn-icon"
            onClick={() => setShowAnalytics(true)}
            title="Analytics dashboard"
            aria-label="Open analytics dashboard"
            type="button"
          >
            <BarChart3 size={16} />
          </button>
          <div className={`net-badge ${isOnline ? 'online' : 'offline'}`}>
            {isOnline ? <Wifi size={14} /> : <WifiOff size={14} />}
            {isOnline ? 'Online' : 'Offline — running on device'}
          </div>
        </div>
      </header>

      <main className="app-main">
        {showAnalytics && (
          <AnalyticsDashboard onClose={() => setShowAnalytics(false)} refreshKey={savedReportId} />
        )}

        {!showAnalytics && stage === STAGES.CAPTURE && (
          <section className="stage stage-capture">
            <p className="stage-intro">
              Photograph the patient or scene. Analysis and compression happen entirely on
              this device — nothing is uploaded.
            </p>
            <CameraModule onCapture={handleCapture} />
          </section>
        )}

        {!showAnalytics && stage === STAGES.ANALYZING && (
          <section className="stage stage-analyzing">
            {rawImage && <img src={rawImage} alt="Captured" className="analyzing-thumb" />}
            <Loader2 className="spin" size={28} />
            <p>Analyzing…</p>
            <p className="stage-note">
              Runs entirely on-device — WASM model inference when available, Canvas heuristic
              fallback otherwise. No download, no network call.
            </p>
          </section>
        )}

        {!showAnalytics && stage === STAGES.REVIEW && (
          <section className="stage stage-review">
            {preview && (
              <div className="review-thumb-wrap">
                <img src={preview} alt="Analyzed frame" className="review-thumb" />
                {analysis?.saliency && (
                  <SaliencyOverlay saliency={analysis.saliency} gridSize={analysis.gridSize} />
                )}
              </div>
            )}

            {analysisError && <div className="alert alert-warn">{analysisError}</div>}

            {analysis?.fallbackReason && (
              <div className="alert alert-info">
                <Info size={14} /> {analysis.fallbackReason}
              </div>
            )}

            {predictions.length > 0 && (
              <div className="prediction-list">
                <p className="section-label">
                  {analysis.source === 'model'
                    ? 'On-device model prediction'
                    : 'On-device visual signal (heuristic)'}
                </p>
                {predictions.slice(0, 3).map((p) => (
                  <div className="prediction-row" key={p.label}>
                    <span>{p.label}</span>
                    <span>{Math.round(p.score * 100)}%</span>
                  </div>
                ))}
              </div>
            )}

            <div className="assessment-toggle" role="tablist" aria-label="Assessment mode">
              <button
                type="button"
                role="tab"
                aria-selected={assessmentMode === 'start'}
                className={`toggle-chip ${assessmentMode === 'start' ? 'active' : ''}`}
                onClick={() => setAssessmentMode('start')}
              >
                START protocol
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={assessmentMode === 'manual'}
                className={`toggle-chip ${assessmentMode === 'manual' ? 'active' : ''}`}
                onClick={() => setAssessmentMode('manual')}
              >
                Quick manual
              </button>
            </div>

            {assessmentMode === 'start' ? (
              <StartAssessment onComplete={(result) => setStartResult(result)} />
            ) : (
              <SeveritySlider value={manualSeverity} onChange={setManualSeverity} />
            )}

            <BodyMap selected={bodyRegions} onChange={setBodyRegions} />

            <div className="geo-row">
              <MapPin size={14} />
              {coords ? (
                <span>{coords.lat}, {coords.lon}</span>
              ) : (
                <>
                  <span>{geoError || 'Acquiring GPS…'}</span>
                  {geoError && (
                    <button className="geo-retry" onClick={requestLocation} type="button">
                      Retry
                    </button>
                  )}
                </>
              )}
            </div>

            <button className="btn btn-primary" disabled={!triage} onClick={handleGenerateCode}>
              Generate triage code <ChevronRight size={16} />
            </button>
          </section>
        )}

        {!showAnalytics && stage === STAGES.RESULT && triage && (
          <section className="stage stage-result">
            <div className={`triage-banner cat-${triage.category.toLowerCase()}`}>
              <span className="triage-color-dot" />
              <div>
                <p className="triage-category">
                  {triage.label} — {CATEGORY_META[triage.category].color}
                </p>
                <p className="triage-confidence">
                  Confidence {Math.round(triage.confidence * 100)}% ·{' '}
                  {triage.source === 'manual'
                    ? 'Operator confirmed'
                    : triage.source === 'start-protocol'
                    ? 'START protocol'
                    : analysis?.source === 'model'
                    ? 'Model suggested'
                    : 'Heuristic suggested'}
                </p>
              </div>
            </div>

            {bodyRegions.length > 0 && (
              <div className="result-regions">
                {bodyRegions.map((r) => (
                  <span key={r} className="body-tag">
                    {r}
                  </span>
                ))}
              </div>
            )}

            <QROutput payload={payload} byteSize={new TextEncoder().encode(payload).length} />

            <p className="stage-note">
              {savedReportId
                ? 'Saved locally — will show in analytics and relay queue.'
                : 'Could not save locally.'}
            </p>

            <button className="btn btn-ghost" onClick={reset}>
              New capture
            </button>
          </section>
        )}
      </main>

      <footer className="app-footer">
        <span>Zero backend · Zero cloud calls · Zero downloads · Fully offline, always</span>
      </footer>
    </div>
  );
}

function evaluateTriageFinding(label) {
  try {
    return evaluateTriage([{ label, score: 1 }], null).findingsCode;
  } catch {
    return null;
  }
}

function useOnlineStatus() {
  const [online, setOnline] = useState(navigator.onLine);
  if (typeof window !== 'undefined') {
    window.ononline = () => setOnline(true);
    window.onoffline = () => setOnline(false);
  }
  return online;
}
