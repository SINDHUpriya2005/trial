/**
 * db.js
 * IndexedDB persistence layer (via the `idb` helper) for offline
 * triage reports. Every completed triage is written locally so the
 * app is fully usable with no connectivity at all, and so the
 * analytics dashboard has real data to aggregate. A lightweight
 * "sync" flag models handoff to a relief coordination system once
 * connectivity returns — this app makes no network calls itself, so
 * "sync" here means marking records ready for an operator to relay
 * (QR/SMS/radio) or for a future connected build to push out.
 */

import { openDB } from 'idb';

const DB_NAME = 'whispertriage';
const DB_VERSION = 1;
const STORE = 'reports';

let dbPromise = null;

function getDB() {
  if (!dbPromise) {
    dbPromise = openDB(DB_NAME, DB_VERSION, {
      upgrade(db) {
        const store = db.createObjectStore(STORE, { keyPath: 'id' });
        store.createIndex('by-timestamp', 'timestamp');
        store.createIndex('by-category', 'category');
        store.createIndex('by-synced', 'synced');
      }
    });
  }
  return dbPromise;
}

/**
 * Persists a completed triage report locally.
 * @returns {Promise<string>} the generated report id
 */
export async function saveReport(report) {
  const db = await getDB();
  const id = report.id || `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const record = {
    id,
    timestamp: report.timestamp || Date.now(),
    category: report.category,
    findingsCode: report.findingsCode,
    confidence: report.confidence,
    source: report.source,
    payload: report.payload,
    coords: report.coords || null,
    bodyRegions: report.bodyRegions || [],
    thumbnail: report.thumbnail || null,
    synced: false
  };
  await db.put(STORE, record);
  return id;
}

export async function markSynced(id) {
  const db = await getDB();
  const record = await db.get(STORE, id);
  if (!record) return;
  record.synced = true;
  await db.put(STORE, record);
}

export async function getAllReports() {
  const db = await getDB();
  const all = await db.getAll(STORE);
  return all.sort((a, b) => b.timestamp - a.timestamp);
}

export async function getUnsyncedCount() {
  const db = await getDB();
  const all = await db.getAllFromIndex(STORE, 'by-synced');
  return all.filter((r) => r.synced === false).length;
}

export async function deleteReport(id) {
  const db = await getDB();
  await db.delete(STORE, id);
}

export async function clearAllReports() {
  const db = await getDB();
  await db.clear(STORE);
}

/**
 * Aggregates stored reports into analytics-dashboard-ready summary
 * data: counts per START category, counts per finding code, and a
 * simple per-hour timeline for the last 24h of activity.
 */
export async function getAnalyticsSummary() {
  const reports = await getAllReports();

  const byCategory = { IMMEDIATE: 0, DELAYED: 0, MINOR: 0, EXPECTANT: 0 };
  const byFinding = {};
  const hourBuckets = Array.from({ length: 24 }, () => 0);
  const now = Date.now();

  for (const r of reports) {
    if (byCategory[r.category] !== undefined) byCategory[r.category]++;
    byFinding[r.findingsCode] = (byFinding[r.findingsCode] || 0) + 1;

    const ageHours = (now - r.timestamp) / 3_600_000;
    if (ageHours >= 0 && ageHours < 24) {
      const bucket = 23 - Math.floor(ageHours);
      hourBuckets[bucket]++;
    }
  }

  const unsynced = reports.filter((r) => !r.synced).length;

  return {
    total: reports.length,
    byCategory,
    byFinding,
    hourBuckets,
    unsynced,
    avgConfidence: reports.length
      ? reports.reduce((sum, r) => sum + (r.confidence || 0), 0) / reports.length
      : 0
  };
}
