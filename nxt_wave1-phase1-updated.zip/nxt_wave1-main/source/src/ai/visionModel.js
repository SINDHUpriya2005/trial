/**
 * visionModel.js
 * Real on-device ML inference pipeline using ONNX Runtime Web (WASM
 * execution provider — no network, no server, model file shipped in
 * /public/models and cached by the service worker).
 *
 * HONEST SCOPE NOTE — READ THIS BEFORE DEPLOYING:
 * This repository ships WITHOUT a trained model weight file. The
 * `/public/models/wound-classifier.onnx` path is a placeholder. This
 * module probes for that file at startup; if it is missing (404) or
 * fails to load, it reports `unavailable` and the app cleanly falls
 * back to the deterministic Canvas heuristic in visionHeuristics.js
 * (see runVisionAnalysis() in index.js of this folder). Nothing is
 * silently faked — the UI tells the operator which path produced the
 * result. See README.md → "Adding a real model" for how to train and
 * drop in a compatible ONNX classifier (single 224x224x3 RGB input,
 * softmax output over CLASS_LABELS below).
 *
 * ── Explainable AI ──────────────────────────────────────────────────
 * Rather than bolting on an unverifiable "AI explanation" string, this
 * module computes real occlusion-sensitivity saliency: it re-runs
 * inference with each patch of a coarse grid blanked out, and measures
 * how much the top class's probability drops. Patches whose removal
 * causes the biggest drop are the regions the model actually relied
 * on — a standard, model-agnostic XAI technique (Zeiler & Fergus,
 * 2014) that requires no gradient access, which matters here because
 * onnxruntime-web's default execution provider does not expose one.
 */

import { canvasToTensorData } from '../utils/imageCompressor.js';

// onnxruntime-web pulls in a large WASM runtime (multi-MB). It is
// dynamically imported only once we've confirmed a model file exists
// (isModelAvailable), so the app's default bundle — the common case,
// since this repo ships without a trained model — stays small.
let ortModule = null;
async function getOrt() {
  if (!ortModule) {
    const mod = await import('onnxruntime-web');
    // Multi-threaded WASM needs SharedArrayBuffer, which requires
    // Cross-Origin-Opener-Policy/Cross-Origin-Embedder-Policy response
    // headers. GitHub Pages (this app's deploy target, see README §4.5)
    // can't set those. Forcing single-threaded execution keeps the
    // model usable on a plain static host at some cost to inference
    // speed — the right trade-off here, matching this app's existing
    // "reliability over raw performance" stance (README §4.1).
    mod.env.wasm.numThreads = 1;
    mod.env.wasm.simd = true;
    ortModule = mod;
  }
  return ortModule;
}

export const CLASS_LABELS = [
  'No significant finding',
  'First-degree burn',
  'Second-degree burn',
  'Third-degree / charred tissue',
  'Laceration / open wound',
  'Active hemorrhage signal',
  'Suspected fracture deformity'
];

const MODEL_URL = `${import.meta.env.BASE_URL}models/wound-classifier.onnx`;
const OCCLUSION_GRID = 4; // 4x4 = 16 patches; balance of resolution vs. extra forward passes

let sessionPromise = null;
let availability = null; // null = unknown, true/false = probed

/**
 * Cheaply checks whether a model file is actually present before
 * attempting a full ORT session load (which throws a noisier error).
 */
export async function isModelAvailable() {
  if (availability !== null) return availability;
  try {
    const res = await fetch(MODEL_URL, { method: 'HEAD' });
    availability = res.ok;
  } catch {
    availability = false;
  }
  return availability;
}

async function getSession() {
  if (!sessionPromise) {
    sessionPromise = getOrt()
      .then((ort) => ort.InferenceSession.create(MODEL_URL, { executionProviders: ['wasm'] }))
      .catch((err) => {
        sessionPromise = null;
        throw err;
      });
  }
  return sessionPromise;
}

function softmax(arr) {
  const max = Math.max(...arr);
  const exps = arr.map((v) => Math.exp(v - max));
  const sum = exps.reduce((a, b) => a + b, 0);
  return exps.map((v) => v / sum);
}

async function runInference(session, canvas) {
  const ort = await getOrt();
  const { data, dims } = canvasToTensorData(canvas);
  const tensor = new ort.Tensor('float32', data, dims);
  const inputName = session.inputNames[0];
  const outputName = session.outputNames[0];
  const results = await session.run({ [inputName]: tensor });
  return softmax(Array.from(results[outputName].data));
}

/**
 * Produces an occlusion-sensitivity heatmap for the top predicted
 * class: an OCCLUSION_GRID x OCCLUSION_GRID array of "importance"
 * scores (0-1, normalized), where higher = removing that region
 * dropped the model's confidence more, i.e. the model leaned on it.
 */
async function occlusionSaliency(session, canvas, topClassIndex, baseProb) {
  const size = canvas.width;
  const patch = size / OCCLUSION_GRID;
  const heat = [];

  const scratch = document.createElement('canvas');
  scratch.width = size;
  scratch.height = size;
  const sctx = scratch.getContext('2d', { willReadFrequently: true });

  for (let row = 0; row < OCCLUSION_GRID; row++) {
    const rowScores = [];
    for (let col = 0; col < OCCLUSION_GRID; col++) {
      sctx.drawImage(canvas, 0, 0);
      sctx.fillStyle = '#7f7f7f'; // neutral gray occlusion, avoids biasing color heuristics
      sctx.fillRect(col * patch, row * patch, patch, patch);

      // eslint-disable-next-line no-await-in-loop
      const probs = await runInference(session, scratch);
      const drop = Math.max(baseProb - probs[topClassIndex], 0);
      rowScores.push(drop);
    }
    heat.push(rowScores);
  }

  const max = Math.max(...heat.flat(), 1e-6);
  return heat.map((row) => row.map((v) => v / max));
}

/**
 * Runs the full model pipeline: classification + confidence scores
 * for every class + an occlusion-saliency feature map explaining the
 * top prediction.
 *
 * @param {HTMLCanvasElement} canvas - pre-resized (e.g. 224x224) frame
 * @returns {{ranked: Array<{label:string, score:number}>, saliency: number[][], modelVersion: string}}
 */
export async function classifyWithModel(canvas) {
  const session = await getSession();
  const probs = await runInference(session, canvas);

  const ranked = CLASS_LABELS.map((label, i) => ({ label, score: probs[i] })).sort(
    (a, b) => b.score - a.score
  );

  const topIndex = CLASS_LABELS.indexOf(ranked[0].label);
  const saliency = await occlusionSaliency(session, canvas, topIndex, probs[topIndex]);

  return {
    ranked,
    saliency,
    gridSize: OCCLUSION_GRID,
    modelVersion: session.inputNames ? 'onnx-wasm-v1' : 'unknown'
  };
}
