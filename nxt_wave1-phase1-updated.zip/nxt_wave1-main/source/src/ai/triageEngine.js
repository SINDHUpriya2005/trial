/**
 * triageEngine.js
 * Converts the heuristic vision signal (visionHeuristics.js) and/or
 * an operator's manual severity selection into a START-aligned triage
 * result.
 *
 * START = Simple Triage and Rapid Treatment, the standard mass-casualty
 * field protocol: IMMEDIATE (red) / DELAYED (yellow) / MINOR (green) /
 * EXPECTANT (black).
 *
 * HONEST SCOPE NOTE: the vision signal is a coarse Canvas-pixel
 * heuristic (redness, dark/charred tone, texture irregularity) — not
 * a trained classifier and not a diagnosis. It is one input signal;
 * the operator's manual severity selection, when provided, always
 * takes priority. This app is a documentation/compression/
 * transmission aid, not an autonomous diagnostic device.
 */

import { HEURISTIC_LABELS } from './visionHeuristics.js';
import { CLASS_LABELS } from './visionModel.js';

const LABEL_TO_TRIAGE = {
  [HEURISTIC_LABELS.CHARRED]: { category: 'IMMEDIATE', findingsCode: 'BURN3' },
  [HEURISTIC_LABELS.BURN]: { category: 'DELAYED', findingsCode: 'BURN2' },
  [HEURISTIC_LABELS.IRREGULAR]: { category: 'DELAYED', findingsCode: 'LACER' },
  [HEURISTIC_LABELS.UNIFORM]: { category: 'MINOR', findingsCode: 'AMBUL' },

  // Real-model class labels (visionModel.js) map to the same
  // START-aligned categories/finding codes as their heuristic
  // counterparts, so downstream logic (packPayload, UI) is identical
  // regardless of which analysis path produced the signal.
  [CLASS_LABELS[0]]: { category: 'MINOR', findingsCode: 'AMBUL' }, // No significant finding
  [CLASS_LABELS[1]]: { category: 'MINOR', findingsCode: 'BURN1' }, // First-degree burn
  [CLASS_LABELS[2]]: { category: 'DELAYED', findingsCode: 'BURN2' }, // Second-degree burn
  [CLASS_LABELS[3]]: { category: 'IMMEDIATE', findingsCode: 'BURN3' }, // Third-degree / charred
  [CLASS_LABELS[4]]: { category: 'DELAYED', findingsCode: 'LACER' }, // Laceration / open wound
  [CLASS_LABELS[5]]: { category: 'IMMEDIATE', findingsCode: 'HEMOR' }, // Active hemorrhage
  [CLASS_LABELS[6]]: { category: 'DELAYED', findingsCode: 'FRACT' } // Suspected fracture
};

const SEVERITY_TO_CATEGORY = {
  1: 'MINOR',
  2: 'MINOR',
  3: 'DELAYED',
  4: 'DELAYED',
  5: 'IMMEDIATE',
  6: 'IMMEDIATE',
  7: 'EXPECTANT'
};

const SEVERITY_TO_FINDINGS = {
  1: 'AMBUL',
  2: 'AMBUL',
  3: 'LACER',
  4: 'FRACT',
  5: 'HEMOR',
  6: 'RESP',
  7: 'UNRES'
};

const CATEGORY_META = {
  IMMEDIATE: { color: 'RED', label: 'Immediate', priority: 1 },
  DELAYED: { color: 'YELLOW', label: 'Delayed', priority: 2 },
  MINOR: { color: 'GREEN', label: 'Minor', priority: 3 },
  EXPECTANT: { color: 'BLACK', label: 'Expectant', priority: 4 }
};

/**
 * Combines the heuristic signal with an optional operator-selected
 * severity (1-7, from the on-screen manual triage slider) to produce
 * a final triage result.
 *
 * @param {Array<{label:string, score:number}>} signals - output of analyzeImage()
 * @param {number|null} manualSeverity - 1(minor)-7(expectant), or null
 *   if the operator has not made a manual selection yet.
 */
export function evaluateTriage(signals = [], manualSeverity = null) {
  const top = signals[0];
  let category = 'DELAYED';
  let findingsCode = 'UNK';
  let confidence = top ? top.score : 0.5;
  let source = 'heuristic';

  if (top && LABEL_TO_TRIAGE[top.label]) {
    category = LABEL_TO_TRIAGE[top.label].category;
    findingsCode = LABEL_TO_TRIAGE[top.label].findingsCode;
  }

  // Manual severity, when provided, is authoritative — a trained
  // responder's field judgment always outranks the heuristic signal.
  if (manualSeverity && SEVERITY_TO_CATEGORY[manualSeverity]) {
    category = SEVERITY_TO_CATEGORY[manualSeverity];
    findingsCode = SEVERITY_TO_FINDINGS[manualSeverity];
    confidence = 1.0;
    source = 'manual';
  }

  const meta = CATEGORY_META[category];

  return {
    category,
    color: meta.color,
    label: meta.label,
    priority: meta.priority,
    findingsCode,
    confidence,
    source,
    rawTopLabel: top ? top.label : null
  };
}

/**
 * ── START decision tree ─────────────────────────────────────────────
 * Implements the actual Simple Triage and Rapid Treatment algorithm
 * (Ambulatory → Respirations → Perfusion → Mental status), the field
 * standard for mass-casualty sorting. This is independent of the
 * vision signal — a responder walks through it directly with the
 * patient. Vision/manual-severity findings (above) describe *what
 * injury*; this describes *how urgently*, per the actual protocol.
 *
 * @param {Object} answers
 * @param {boolean} answers.canWalk
 * @param {boolean} [answers.isBreathing] - only asked if !canWalk
 * @param {boolean} [answers.repositioned] - airway reposition attempted, only if !isBreathing
 * @param {boolean} [answers.breathingAfterReposition]
 * @param {number} [answers.respiratoryRate] - breaths/min, only if breathing
 * @param {boolean} [answers.radialPulsePresent] - or cap refill < 2s
 * @param {boolean} [answers.canFollowCommands]
 * @returns {{category: string, step: string, reasoning: string[]}}
 */
export function runSTART(answers) {
  const reasoning = [];

  if (answers.canWalk) {
    reasoning.push('Ambulatory — able to walk to a collection point unassisted.');
    return { category: 'MINOR', step: 'ambulatory', reasoning };
  }
  reasoning.push('Not ambulatory — proceeding to respirations check.');

  if (!answers.isBreathing) {
    reasoning.push('Not breathing on first check.');
    if (!answers.repositioned || !answers.breathingAfterReposition) {
      reasoning.push('No spontaneous respirations after airway repositioning.');
      return { category: 'EXPECTANT', step: 'respirations', reasoning };
    }
    reasoning.push('Breathing resumed after airway repositioning.');
    return { category: 'IMMEDIATE', step: 'respirations', reasoning };
  }

  if (typeof answers.respiratoryRate === 'number' && answers.respiratoryRate > 30) {
    reasoning.push(`Respiratory rate ${answers.respiratoryRate}/min exceeds 30/min.`);
    return { category: 'IMMEDIATE', step: 'respirations', reasoning };
  }
  reasoning.push('Breathing, respiratory rate ≤ 30/min — proceeding to perfusion check.');

  if (!answers.radialPulsePresent) {
    reasoning.push('Radial pulse absent / capillary refill ≥ 2s — inadequate perfusion.');
    return { category: 'IMMEDIATE', step: 'perfusion', reasoning };
  }
  reasoning.push('Radial pulse present — proceeding to mental status check.');

  if (!answers.canFollowCommands) {
    reasoning.push('Unable to follow simple commands — altered mental status.');
    return { category: 'IMMEDIATE', step: 'mental-status', reasoning };
  }
  reasoning.push('Able to follow simple commands.');
  return { category: 'DELAYED', step: 'mental-status', reasoning };
}

export { CATEGORY_META, SEVERITY_TO_CATEGORY };
