/**
 * visionHeuristics.js
 * Analyzes a captured photo entirely via <canvas> pixel math — no
 * downloaded model, no WASM runtime, no network fetch of any kind.
 *
 * HONEST SCOPE NOTE: this is a coarse visual heuristic, not a trained
 * classifier and not a diagnosis. It flags color/texture signals
 * (true red hues distinct from ordinary skin warmth, dark/charred
 * tone, irregular hue texture) that commonly correlate with burns,
 * inflammation, bleeding, or open wounds, and always defers to the
 * operator's manual severity selection, which is authoritative — see
 * triageEngine.js. See README.md, "Design decisions" section, for the
 * full reasoning behind this approach over a downloaded ML model.
 *
 * ── How classification works ──────────────────────────────────────
 * 1. Every pixel is converted to HSV (hue/saturation/value) rather
 *    than compared in raw RGB. This matters: ordinary skin, across
 *    nearly the whole range of human skin tones, is R>G>B in raw RGB
 *    (a mid-orange hue, roughly 15-40°). A naive "is red the loudest
 *    channel" check flags almost any skin as an injury. Restricting
 *    to hues near true red (0°±12°) at real saturation avoids that.
 * 2. Three raw signals are tallied across the frame: the fraction of
 *    pixels that are true-red (redRatio), the fraction that are
 *    near-black/charred (charRatio), and the variance of hue among
 *    chromatic pixels (hueVariance) — high variance means a broken-up,
 *    irregular color texture (wound edges, exposed tissue layers)
 *    rather than uniform skin.
 * 3. Each raw ratio is converted to a 0-1 confidence by dividing by a
 *    "ceiling" — the ratio at which that signal is considered fully
 *    present. These ceilings are deliberately low (e.g. 15% of the
 *    frame being true-red pixels is already a strong signal) because
 *    a real injury in a centered field photo typically occupies a
 *    minority of the frame, not a majority — an earlier version of
 *    this heuristic used "whichever score is highest, including a
 *    complement/uniform score" and that let a photo that was 90%
 *    normal skin and 9% clear redness get classified as "no signal,"
 *    which is backwards. Confidence now measures "how much of this
 *    specific signal is present," and any signal clearing its trigger
 *    floor wins over the uniform/no-signal default.
 */

const LABELS = {
  CHARRED: 'Dark/charred tissue signal',
  BURN: 'True-red hue detected — possible burn, inflammation, or bleeding',
  IRREGULAR: 'Irregular hue texture — possible open wound',
  UNIFORM: 'Low variance — no strong injury signal'
};

// Pixel-classification thresholds.
const CHAR_VALUE_MAX = 0.22; // HSV value below this = charred/near-black
const RED_HUE_SPAN = 12; // degrees either side of 0/360 counted as "true red"
const RED_SAT_MIN = 0.35; // minimum saturation to count as true red (excludes washed-out pink)
const RED_VALUE_MIN = 0.15; // excludes pixels already counted as charred
const CHROMA_SAT_MIN = 0.15; // minimum saturation for a pixel to count toward hue-variance sampling
const CHROMA_VALUE_MIN = 0.1;

// Confidence ceilings: the raw ratio at which a signal is scored as
// "fully present" (confidence 1.0). Tuned against real photos, not
// just synthetic test patterns — see README.md "Testing methodology."
const BURN_CEILING = 0.15; // 15% true-red pixels = full confidence
const CHAR_CEILING = 0.06; // charring is serious even in small amounts, so a lower ceiling
const IRREGULAR_CEILING = 0.3;

// Minimum confidence a signal must clear to be reported as the
// finding, instead of falling back to "no strong injury signal."
const TRIGGER_FLOOR = 0.18;

/**
 * Runs the heuristic pass over a canvas already sized to a standard
 * analysis resolution (see imageCompressor.js).
 *
 * @param {HTMLCanvasElement} canvas
 * @returns {Array<{label: string, score: number}>} sorted descending by score
 */
export function analyzeImage(canvas) {
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  const { width, height } = canvas;
  const { data } = ctx.getImageData(0, 0, width, height);

  const totalPixels = width * height;
  let redCount = 0;
  let charCount = 0;
  let hueSum = 0;
  let hueSumSq = 0;
  let hueSamples = 0;

  for (let i = 0; i < data.length; i += 4) {
    const [h, s, v] = rgbToHsv(data[i], data[i + 1], data[i + 2]);

    if (v < CHAR_VALUE_MAX) {
      charCount++;
    }

    if ((h < RED_HUE_SPAN || h > 360 - RED_HUE_SPAN) && s > RED_SAT_MIN && v > RED_VALUE_MIN) {
      redCount++;
    }

    if (s > CHROMA_SAT_MIN && v > CHROMA_VALUE_MIN) {
      hueSum += h;
      hueSumSq += h * h;
      hueSamples++;
    }
  }

  const redRatio = redCount / totalPixels;
  const charRatio = charCount / totalPixels;

  let hueVarianceNorm = 0;
  if (hueSamples > 8) {
    const mean = hueSum / hueSamples;
    const variance = Math.max(hueSumSq / hueSamples - mean * mean, 0);
    hueVarianceNorm = clamp(Math.sqrt(variance) / 60, 0, 1);
  }

  const confidence = {
    [LABELS.CHARRED]: clamp(charRatio / CHAR_CEILING, 0, 1),
    [LABELS.BURN]: clamp(redRatio / BURN_CEILING, 0, 1),
    [LABELS.IRREGULAR]: clamp(hueVarianceNorm / IRREGULAR_CEILING, 0, 1)
  };

  const ranked = Object.entries(confidence).sort((a, b) => b[1] - a[1]);
  const [topLabel, topScore] = ranked[0];

  const results =
    topScore >= TRIGGER_FLOOR
      ? ranked
      : [[LABELS.UNIFORM, clamp(1 - topScore, 0, 1)], ...ranked];

  return results.map(([label, score]) => ({ label, score }));
}

/**
 * Converts 0-255 RGB to [hue 0-360, saturation 0-1, value 0-1].
 */
function rgbToHsv(r, g, b) {
  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;

  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const chroma = max - min;

  let hue = 0;
  if (chroma > 0) {
    if (max === rn) {
      hue = ((gn - bn) / chroma) % 6;
    } else if (max === gn) {
      hue = (bn - rn) / chroma + 2;
    } else {
      hue = (rn - gn) / chroma + 4;
    }
    hue *= 60;
    if (hue < 0) hue += 360;
  }

  const saturation = max === 0 ? 0 : chroma / max;
  const value = max;

  return [hue, saturation, value];
}

function clamp(n, min, max) {
  return Math.min(Math.max(n, min), max);
}

export { LABELS as HEURISTIC_LABELS };
