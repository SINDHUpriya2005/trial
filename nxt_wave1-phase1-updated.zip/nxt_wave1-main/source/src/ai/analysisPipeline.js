/**
 * analysisPipeline.js
 * Single entry point the UI calls for image analysis. Tries the real
 * ONNX model first; if unavailable or it throws, falls back to the
 * deterministic Canvas heuristic. The caller always learns which path
 * produced the result (`source`) so the UI can be honest about it —
 * never presents a heuristic guess as if it were a trained model's
 * output, or vice versa.
 */

import { analyzeImage } from './visionHeuristics.js';
import { isModelAvailable, classifyWithModel } from './visionModel.js';

/**
 * @param {HTMLCanvasElement} canvas
 * @returns {{
 *   source: 'model' | 'heuristic',
 *   predictions: Array<{label:string, score:number}>,
 *   saliency: number[][] | null,
 *   gridSize: number | null,
 *   modelVersion: string | null,
 *   fallbackReason: string | null
 * }}
 */
export async function runVisionAnalysis(canvas) {
  const available = await isModelAvailable();

  if (available) {
    try {
      const { ranked, saliency, gridSize, modelVersion } = await classifyWithModel(canvas);
      return {
        source: 'model',
        predictions: ranked,
        saliency,
        gridSize,
        modelVersion,
        fallbackReason: null
      };
    } catch (err) {
      console.warn('Model inference failed, falling back to heuristic:', err);
      return {
        source: 'heuristic',
        predictions: analyzeImage(canvas),
        saliency: null,
        gridSize: null,
        modelVersion: null,
        fallbackReason: 'Model inference failed at runtime — see console for details.'
      };
    }
  }

  return {
    source: 'heuristic',
    predictions: analyzeImage(canvas),
    saliency: null,
    gridSize: null,
    modelVersion: null,
    fallbackReason: 'No on-device model file was found (see README → "Adding a real model").'
  };
}
