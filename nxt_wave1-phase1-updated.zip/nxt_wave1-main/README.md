# WhisperTriage AI — Ready to Deploy

**Problem it targets**: 

Under Emergency Management / Disaster Response — when cellular networks degrade or fail (2G collapse, grid-down disasters), responders can't upload patient data to cloud triage tools. Most crisis apps assume connectivity that simply isn't there when it matters most.


**Solution:** 

A zero-backend, offline-first triage assistant. Responder photographs a patient/scene → on-device AI analyzes it → operator confirms a START triage category (Immediate/Delayed/Minor/Expectant) → GPS + timestamp + finding get compressed into a QR code under 100 bytes, transmittable device-to-device, by radio, or SMS — no internet required at the point of use.
AI at the core: On-device computer vision analyzes each captured photo in HSV color space — classifying redness (bleeding/inflammation/burn), charring (severe burn tissue), and texture irregularity (open wounds) — functioning as a real-time decision-support signal that the operator confirms or overrides. This runs synchronously in the browser with zero network dependency, which is itself the key AI-engineering decision: an earlier version used a downloaded transformer model and it was rejected specifically because a 2G-network responder can't reliably download 100MB+ of model weights — the AI approach was deliberately shaped by the disaster-connectivity constraint, not the other way around.

**Why it fits "AI that works when people need it most" specifically**: 

most competing ideas in this theme will assume network access to call an LLM/cloud API. This one is built for the actual failure mode disasters cause — no network at all — and still produces a usable, actionable output.

**Deployable today**: 

static site, GitHub Pages, no backend, no API keys, no login — matches the "must be live, accessible without login" submission requirement directly.


**Everything at this top level is the already-built, ready-to-serve website.**

No build step needed. Push the contents of this folder (as they are,
including `.nojekyll`) to whatever GitHub Pages is serving — repo root
on the `main`/`gh-pages` branch, or wherever Settings → Pages points —
and it will work immediately.

```
(this folder)/
├── index.html          ← entry point, must sit at the served root
├── assets/              ← compiled JS + CSS bundle (~223 KB total)
├── manifest.json        ← PWA manifest
├── sw.js                 ← offline service worker
├── icons/, favicon.svg, icons.svg
├── .nojekyll             ← tells GitHub Pages to skip Jekyll processing
└── source/               ← full editable project source + full documentation
```

## Deploying (do this exactly)

1. Create/open your GitHub repository (e.g. `nxt_wave`).
2. Copy **everything in this folder except the `source/` subfolder**
   into the repo, at the root of the branch/folder that Settings →
   Pages is configured to serve. `index.html` must end up directly at
   that root — e.g. `your-repo/index.html`, not
   `your-repo/dist/index.html` or `your-repo/whispertriage/index.html`.
3. Commit and push.
4. Visit `https://<your-username>.github.io/<repo-name>/`.

No `npm install`, no `npm run build`, no model download of any kind.

## If you deployed the app before this version

Browsers cache the service worker aggressively. Open DevTools →
Application → Service Workers → **Unregister**, then Application →
Storage → **Clear site data**, then hard-refresh. This build bumps the
service worker's internal cache name specifically to force old cached
copies to be replaced.

## Full documentation

**`source/README.md` is the complete write-up** — the problem this app
solves, the full architecture, every design decision and why it was
made (including why an earlier version used a downloaded AI model and
why that was replaced, and a real bug that was caught and fixed in
testing), the START triage protocol, known limitations, and possible
future work. Read that for the full picture; this file only covers
"how do I get it live."

## If you want to change the code later

```bash
cd source
npm install
npm run build
```

Then copy the new contents of `source/dist/` back to this top level
(replacing `index.html`, `assets/`, etc.) and redeploy.
